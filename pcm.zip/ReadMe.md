Requirements:
1. Node.js
2. NPM

Install & Usage
1. Set download path correctly on server.js
2. npm install 
3. npm start

Have to Know:

Choose:
1. Copy input audios to input folder and select that files.
2. Set download path and click convert then it will saved to that path.

Recording:
1. You can start recording and click convert button then
2. All recording files will be save to output folder
    
All files will be converted to 8kHz audio file.